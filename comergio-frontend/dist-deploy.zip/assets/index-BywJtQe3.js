const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["assets/web-CMDaV4Tu.js","assets/index-Cc4kZvpy.js","assets/index-Dgl31Jj8.css"])))=>i.map(i=>d[i]);
import{r,_ as t}from"./index-Cc4kZvpy.js";const o=r("Badge",{web:()=>t(()=>import("./web-CMDaV4Tu.js"),__vite__mapDeps([0,1,2])).then(e=>new e.BadgeWeb)});export{o as Badge};
