const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["assets/web-DnbTJAet.js","assets/index-DOGu2qtC.js","assets/index-Dgl31Jj8.css"])))=>i.map(i=>d[i]);
import{r,_ as t}from"./index-DOGu2qtC.js";const o=r("Badge",{web:()=>t(()=>import("./web-DnbTJAet.js"),__vite__mapDeps([0,1,2])).then(e=>new e.BadgeWeb)});export{o as Badge};
