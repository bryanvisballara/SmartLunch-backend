const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["assets/web-Cci25art.js","assets/index-D5w2L1AV.js","assets/index-DkdjNK0O.css"])))=>i.map(i=>d[i]);
import{r,_ as t}from"./index-D5w2L1AV.js";const o=r("Badge",{web:()=>t(()=>import("./web-Cci25art.js"),__vite__mapDeps([0,1,2])).then(e=>new e.BadgeWeb)});export{o as Badge};
