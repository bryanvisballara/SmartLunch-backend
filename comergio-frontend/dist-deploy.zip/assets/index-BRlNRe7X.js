const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["assets/web-Cv5TdyqH.js","assets/index-CrjDhZXm.js","assets/index-DEa0B5mp.css"])))=>i.map(i=>d[i]);
import{r,_ as t}from"./index-CrjDhZXm.js";const o=r("Badge",{web:()=>t(()=>import("./web-Cv5TdyqH.js"),__vite__mapDeps([0,1,2])).then(e=>new e.BadgeWeb)});export{o as Badge};
